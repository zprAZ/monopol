#include "RailwayPlace.h"

RailwayPlace::RailwayPlace(const int &inp, const QString& name):BoardPlace(inp, name)
{
}

std::unique_ptr<Visitor> RailwayPlace::createVisitor(int playerId) const
{

}

int RailwayPlace::implementGetNumberOfBuildHouses() const
{

}

int RailwayPlace::implementGetNumberOfBuildHotels() const
{

}

void RailwayPlace::implementBuildHouse()
{

}
void RailwayPlace::implementBuildHotel()
{

}

void RailwayPlace::implementSetOwnership(std::shared_ptr<Player> inp)
{

}
