#include "CounterPlace.h"

CounterPlace::CounterPlace(const int &inp, const QString& name):BoardPlace(inp, name)
{
}


std::unique_ptr<Visitor> CounterPlace::createVisitor(int playerId) const
{

}

int CounterPlace::implementGetNumberOfBuildHouses() const
{

}

int CounterPlace::implementGetNumberOfBuildHotels() const
{

}

void CounterPlace::implementBuildHouse()
{

}

void CounterPlace::implementBuildHotel()
{

}

void CounterPlace::implementSetOwnership(std::shared_ptr<Player> inp)
{

}
