#include "GameBoard.h"

GameBoard::GameBoard(QObject *parent) :
    QObject(parent)
{
}
