#ifndef TOKEN_H
#define TOKEN_H

#include <memory>
#include "visitors/Visitor.h"
#include "Player.h"
#include "Pawn.h"

class Token : public Pawn
{
    Q_OBJECT
public:
    explicit Token(const int& id, QObject *parent = 0);
    virtual void accept(Visitor& visitor);
    void setPlayer(std::shared_ptr<Player> inpPlayerPtr);
    // void getPlayerId() const;
signals:

public slots:

private:
    virtual void implementMovement(const int& inp, const QString& message);
    virtual void implementGoToDestination(const int& destination, const bool& startBonus,
                         const QString& message, const bool& forwardDirectionFlag);
    virtual void implementGoToPrison(const int& roundNumber);
    virtual void implementMovePayment(const double& amountPerMove, const QString& playerMessage);

    int current_position_m;
    static int max_position_m;
    std::shared_ptr<Player> player_m;
    const int tokenId;
};

#endif // TOKEN_H
