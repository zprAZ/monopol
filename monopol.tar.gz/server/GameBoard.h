#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include <QObject>

class GameBoard : public QObject
{
    Q_OBJECT
public:
    explicit GameBoard(QObject *parent = 0);

signals:

public slots:

};

#endif // GAMEBOARD_H
