#include "CounterPaymentVisitor.h"
#include "Player.h"
#include "Pawn.h"

CounterPaymentVisitor::CounterPaymentVisitor():amountPerMove(0), message(QString(""))
{
}

std::unique_ptr<Visitor>  CounterPaymentVisitor::createCounterPaymentVisitor()
{
    return std::unique_ptr<Visitor>(new CounterPaymentVisitor);
}

void CounterPaymentVisitor::visit(Pawn& inp)
{

}

void CounterPaymentVisitor::visit(Player& inp)
{
    //do nothing
}

void CounterPaymentVisitor::init(const double& amountPerMove, const QString& message)
{
    this->amountPerMove = amountPerMove;
    this->message = message;
}

std::unique_ptr<Visitor> CounterPaymentVisitor::clone() const
{
    return std::unique_ptr<Visitor>(new CounterPaymentVisitor(*this));
}
