#include "PlayerVisitor.h"

PlayerVisitor::PlayerVisitor()
{
}
