#ifndef COUNTERPAYMENTVISITOR_H
#define COUNTERPAYMENTVISITOR_H

#include "PawnVisitor.h"
#include <memory>
#include <QString>

class CounterPaymentVisitor : public PawnVisitor
{
public:
    CounterPaymentVisitor();
    virtual std::unique_ptr<Visitor> clone() const;
    static std::unique_ptr<Visitor>  createCounterPaymentVisitor();
    virtual void visit(Pawn& inp);
    virtual void visit(Player& inp);
    void init(const double& amountPerMove, const QString& message);
private:
    double amountPerMove;
    QString message;
};

#endif // COUNTERPAYMENTVISITOR_H
