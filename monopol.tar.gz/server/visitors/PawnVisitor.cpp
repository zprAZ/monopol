#include "PawnVisitor.h"

PawnVisitor::PawnVisitor()
{
}
