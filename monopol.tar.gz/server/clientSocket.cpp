#include "clientSocket.h"

clientSocket::clientSocket(QObject *parent) :
    QTcpSocket(parent)
{
}
