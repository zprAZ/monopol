/****************************************************************************
** Meta object code from reading C++ file 'questionDialog.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../client/questionDialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'questionDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_questionDialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      33,   16,   15,   15, 0x05,

 // slots: signature, parameters, type, tag, flags
      70,   58,   15,   15, 0x0a,
      95,   15,   15,   15, 0x08,
     112,   15,   15,   15, 0x08,
     130,   15,   15,   15, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_questionDialog[] = {
    "questionDialog\0\0messageId,answer\0"
    "responseSignal(int,bool)\0id,question\0"
    "setQuestion(int,QString)\0handleDeadline()\0"
    "handleYesButton()\0handleNoButton()\0"
};

void questionDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        questionDialog *_t = static_cast<questionDialog *>(_o);
        switch (_id) {
        case 0: _t->responseSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: _t->setQuestion((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 2: _t->handleDeadline(); break;
        case 3: _t->handleYesButton(); break;
        case 4: _t->handleNoButton(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData questionDialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject questionDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_questionDialog,
      qt_meta_data_questionDialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &questionDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *questionDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *questionDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_questionDialog))
        return static_cast<void*>(const_cast< questionDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int questionDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void questionDialog::responseSignal(int _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
